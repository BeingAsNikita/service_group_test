$(document).ready(function(){
    $("#carousel-1").owlCarousel({
        loop:true,
        margin:10,
        nav:true,
        items: 1,
        dots: true
    });

    $("#carousel-2").owlCarousel({
        loop:true,
        margin: 5,
        nav: true,
        items: 5,
        dots: false
    
    });

  });